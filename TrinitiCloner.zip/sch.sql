update t_job_params set param_value= replace(param_value,?,?);
update t_job_params set param_value= replace(param_value,?,?);
update t_schedules set enabled='false';

