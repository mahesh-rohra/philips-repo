UPDATE stategps.t_gps_notification_details t SET t.to_email_id = ? where to_email_id like ?;
UPDATE stategps.t_gps_notification_details t SET t.CC_EMAIL_ID = ? where CC_EMAIL_ID like ?;
UPDATE stategps.t_gps_notification_details t SET t.BCC_EMAIL_ID = ? where BCC_EMAIL_ID like ?;
update t_gps_custom_sets   set CUSTOM_URL= replace(CUSTOM_URL,?,?);
