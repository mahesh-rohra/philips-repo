UPDATE tas.t_users t SET t.email_id='pdteam@triniti.com';
UPDATE tas.t_roles t SET t.email_id='pdteam@triniti.com';
